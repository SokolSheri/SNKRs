<!DOCTYPE html>
<?php
session_start();
require('includes/mysqli_connect.php');
include('includes/functions.php');

   if(!isset($_SESSION['login_user'])){
      header("location:home.php");
      die();
   }

?>
<html lang="en">

<head>
    
    <title>SNKRS</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link href="snkrs.css" type="text/css" rel="stylesheet">
    
    
    
</head>
    <script src="snkrs.js">
    </script>
<body>
 
     <nav>
        <? if (isset($_SESSION['login_user'])){
    
    echo "<a href='loggedin.php'><img id='snkrs' src='images/snkrs.jpeg'></a>";
    
    
} else{
    echo "<a href='home.php'><img id='snkrs' src='images/snkrs.jpeg'></a>";
    echo "
  <form id='formy' action='login.php' method='post'>
        <br>
      <h3 class='x'>X</h3>
        <img src='images/plus.png' id='logoLogin'>
        <br><br>
        <h3>YOUR ACCOUNT FOR EVERYTHING NIKE</h3>
        <br>
    <input type='text' id='email' name='emailLogin' placeholder='&nbsp;&nbsp;&nbsp;Email'><br>
    <input type='password' id='password' name='passLogin' placeholder='&nbsp;&nbsp;&nbsp;Password'><br>
    <button type='submit' value='submit' id='log'>LOG IN</button><br><br>
        <p id='notMember'>Not a member? <u>Join now</u></p>
    
    
    </form>
    
    <form id='formy2' action='join.php' method='post'>
      <h3 class='x'>X</h3>
        <img src='images/plus.png' id='logoLogin'><br><br>
        <h3>BECOME A MEMBER</h3><br>
    <input type='text' id='email' name='emailJoin' placeholder='&nbsp;&nbsp;&nbsp;Email'><br>
    <input type='password' id='password' name='passJoin' placeholder='&nbsp;&nbsp;&nbsp;Password'><br>
        <input type='text' id='firstName' name='firstJoin' placeholder='&nbsp;&nbsp;&nbsp;First Name'><br>
        <input type='text' id='lastName' name='lastJoin' placeholder='&nbsp;&nbsp;&nbsp;Last Name'><br>
        <input type='date' id='birth' name='birthJoin' placeholder='&nbsp;&nbsp;&nbsp;Date of Birth'><br>
        <div id='gender'>
        <button type='button' id='male' value='MALE'>Male</button>
        <button type='button' id='female' value='FEMALE'>Female</button>
            </div>
        <input type='hidden' name='genderJoin' id='genderJoin'>
        <br>
    <button type='submit' value='submit' id='log2'>JOIN</button>
    </form>";
    
}
        
 ?>
  
  <div>
    <ul>
        <? if (isset($_SESSION['login_user'])){
    
    echo "<a href='loggedout.php'><li id='login'>Log Out</li></a>";
    
    
} else{
    echo "<li id='login'><a>Join/Login</a></li>";
}
        
 ?>
      <li>
          <a href="cart.php"><i class="fa fa-shopping-cart" id="icon"></i></a>
          </li>
        </ul>
  </div>
</nav>
    
    
    <div id="fDiv">
        </div>
   
   
    
    <div id="all">
    
     <div id="items">
    <h5>CART</h5>
    <ul>
         <?php
        
        
		
		 $query = "SELECT sneakers_sizes.sneaker_pic, sneakers_sizes.sneaker_size,sneakers_sizes.sneaker_price,cart.cart_item_id FROM (sneakers_sizes INNER JOIN cart ON sneakers_sizes.sneaker_name = cart.sneaker_id) WHERE cart.user_id='$_SESSION[user_id]';";
		 $run = mysqli_query($dbc, $query);
         
        $subtotal=0;
        $beforeCon='';
        $convert=0;
		 
		 while($row = mysqli_fetch_array($run, MYSQLI_ASSOC)){
             $beforeCon=$row['sneaker_price'];
             $convert=(int)$beforeCon;
            $subtotal= $subtotal+$convert;
             
			 echo "<li><img style='width:20%;' src='images/{$row['sneaker_pic']}'>";
			 echo 'Size '.$row['sneaker_size'];
			 echo " $".$row['sneaker_price']."</li>";
             echo "<form method='get' action='removeItem.php'>";
             echo "<input type='hidden' value='$row[cart_item_id]' name='removeItem'>";
             echo "<input type='submit' value='Remove Item'>";
             echo "</form>";
		 }
		 
        
		
		 ?>
        
        
        
        </ul>
    
    
    </div>
    
    
    
   
        
    <form id="checkoutForm" action="thankYou.php" method="post">
        
      <h4 id="checkoutSummary">SUMMARY</h4> 
         <p id="checkoutText">Subtotal : $<? echo $subtotal;?></p> 
        <p id="checkoutText">Estimated Shipping and Handling: $9.95</p> 
        <p id="checkoutText">Estimated Tax: $<? echo $subtotal*.03;?></p> 
        <br>
        <h6 id="total">Total: $<? echo $subtotal*1.03+9.95; ?></h6> 
        
    <button type="submit" value="checkOutBtn" id="checkOutBtn">CHECK OUT</button>
    
    
    </form>
    </div>
        
     
   
    
  
    
    
        
</body>

</html>