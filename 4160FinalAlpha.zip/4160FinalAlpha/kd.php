<!DOCTYPE html>
<?
session_start();

?>

<html lang="en">

<head>
    
    <title>SNKRS</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link href="snkrs.css" type="text/css" rel="stylesheet"><link href="snkrs.css" type="text/css" rel="stylesheet"><link href="snkrs.css" type="text/css" rel="stylesheet"><link  href="http://cdnjs.cloudflare.com/ajax/libs/fotorama/4.6.4/fotorama.css" rel="stylesheet">
    <script src="http://cdnjs.cloudflare.com/ajax/libs/fotorama/4.6.4/fotorama.js"></script>
</head>
    <script src="snkrs.js"></script>
    
<body>
    

     <nav>
        <? if (isset($_SESSION['login_user'])){
    
    echo "<a href='loggedin.php'><img id='snkrs' src='images/snkrs.jpeg'></a>";
    
    
} else{
    echo "<a href='home.php'><img id='snkrs' src='images/snkrs.jpeg'></a>";
    echo "
  <form id='formy' action='login.php' method='post'>
        <br>
      <h3 class='x'>X</h3>
        <img src='images/plus.png' id='logoLogin'>
        <br><br>
        <h3>YOUR ACCOUNT FOR EVERYTHING NIKE</h3>
        <br>
    <input type='text' id='email' name='emailLogin' placeholder='&nbsp;&nbsp;&nbsp;Email'><br>
    <input type='password' id='password' name='passLogin' placeholder='&nbsp;&nbsp;&nbsp;Password'><br>
    <button type='submit' value='submit' id='log'>LOG IN</button><br><br>
        <p id='notMember'>Not a member? <u>Join now</u></p>
    
    
    </form>
    
    <form id='formy2' action='join.php' method='post'>
      <h3 class='x'>X</h3>
        <img src='images/plus.png' id='logoLogin'><br><br>
        <h3>BECOME A MEMBER</h3><br>
    <input type='text' id='email' name='emailJoin' placeholder='&nbsp;&nbsp;&nbsp;Email'><br>
    <input type='password' id='password' name='passJoin' placeholder='&nbsp;&nbsp;&nbsp;Password'><br>
        <input type='text' id='firstName' name='firstJoin' placeholder='&nbsp;&nbsp;&nbsp;First Name'><br>
        <input type='text' id='lastName' name='lastJoin' placeholder='&nbsp;&nbsp;&nbsp;Last Name'><br>
        <input type='date' id='birth' name='birthJoin' placeholder='&nbsp;&nbsp;&nbsp;Date of Birth'><br>
        <div id='gender'>
        <button type='button' id='male' value='MALE'>Male</button>
        <button type='button' id='female' value='FEMALE'>Female</button>
            </div>
        <input type='hidden' name='genderJoin' id='genderJoin'>
        <br>
    <button type='submit' value='submit' id='log2'>JOIN</button>
    </form>";
    
}
        
 ?>
  
  <div>
    <ul>
        <? if (isset($_SESSION['login_user'])){
    
    echo "<a href='loggedout.php'><li id='login'>Log Out</li></a>";
    
    
} else{
    echo "<li id='login'><a>Join/Login</a></li>";
}
        
 ?>
      <li>
          <a href="cart.php"><i class="fa fa-shopping-cart" id="icon"></i></a>
          </li>
        </ul>
  </div>
</nav>
     <div id="exitImg">
        X
    
    </div>
    <div id="fDiv">
        </div>
    
    
    

       <div class="fotorama caroDisplay" data-height="600" data-width="1000" data-transitio="cross-fade" data-autoplay="true" align="center">

<div data-img="images/kd1.jpg"> </div>
<div data-img="images/kd2.jpg"> </div>
<div data-img="images/kd3.jpg"> </div>
<div data-img="images/kd4.jpg"> </div>
    </div>

    <div id="img1Div">
    
    <img class="sizy" id="img1" src="images/kd1.jpg">
    
    <img class="sizy" id="img2" src="images/kd2.jpg">
    
    </div>
     <div id="img3Div">
    
    <img class="sizy" id="img3" src="images/kd3.jpg">
        
    <img class="sizy" id="img4" src="images/kd4.jpg">
    
    </div>
    
    <div id="description">
    
        <h6>KD 6</h6> <h2>WTKD</h2><p>$200</p>
        <p>Lorem ipsum dolor amet raclette in ut four loko. Vegan nisi asymmetrical palo santo labore 3 wolf moon you probably haven't heard of them sartorial eiusmod ut. Roof party elit bitters, green juice knausgaard qui ad sint activated charcoal non. Plaid yr lyft veniam. Austin gochujang venmo flexitarian intelligentsia. Ad tbh kickstarter, meditation umami venmo subway tile vexillologist. Listicle coloring book wolf pug.</p>
        
      <form action="cartProc.php" method="get"> 
            
            <input type="button" class="shoeSize" id="8" value="8" placeholder="8">
            <input type="button" class="shoeSize" id="9" value="9" placeholder="9">    
            <input type="button" class="shoeSize" id="10" value="10" placeholder="10">
            <input type="button" class="shoeSize" id="11" value="11" placeholder="11">
            <input type="hidden" id="hiddenSize" name="size"><br>
            <button class="btn2" type="submit">ADD TO CART</button>
        </form>
        
        
    </div>
         <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4" crossorigin="anonymous"></script>
   
   
</body>

</html>