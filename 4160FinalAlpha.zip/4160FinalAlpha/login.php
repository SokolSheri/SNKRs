<?php
include("includes/mysqli_connect.php");
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST") {
	$email = mysqli_real_escape_string($dbc,$_POST['emailLogin']);
	$password = mysqli_real_escape_string($dbc,$_POST['passLogin']);
	
	$sql = "SELECT user_id FROM users WHERE email = '$email' and password = '$password'";
	$result = mysqli_query($dbc,$sql);
	$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
	$active = $row['user_id'];
	
	$count = mysqli_num_rows($result);
	
	if($count == 1){
		$_SESSION['login_user'] = $email;
        $_SESSION['user_id']=$active;
		header("location: loggedin.php");
	}else{
		header("location: home.php");
	}
}
/*if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
	header("home.php");
	exit;
}

require_once("includes/mysqli_connect.php");

$email = $password = "";
$email_err = $password_err = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
	if(empty(trim($_POST["email"]))){
		$email_err = "Please enter email.";
	} else{
			$email = trim($_POST["username"]);
	}
if(empty(trim($_POST["password"]))){
	$password_err = "Please enter your password.";
} else{
	$password = trim($_POST["password"]);
}
}
header("location: home.php");*/
?>